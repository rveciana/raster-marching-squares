Marching squares isobands and isolines ready for using along with d3 maps.

The marching squares algorithm code is taken from the [MarchingSquares.js](https://github.com/RaumZeit/MarchingSquares.js) project by [Ronny Lorenz](https://github.com/RaumZeit), adapted to work with nodejs.

